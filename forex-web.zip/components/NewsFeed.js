"use client";
import { useEffect, useState } from "react";

export default function NewsFeed() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    setNews([
      { title: "USD rises ahead of CPI report" },
      { title: "GBP drops after BOE decision" }
    ]);
  }, []);

  return (
    <div>
      <h2>Forex News</h2>
      <ul>
        {news.map((n, i) => <li key={i}>{n.title}</li>)}
      </ul>
    </div>
  );
}
